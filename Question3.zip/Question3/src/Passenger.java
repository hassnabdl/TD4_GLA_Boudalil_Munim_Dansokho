
/**
 * @author DANSO
 *
 */
public class Passenger {
	String name;
	String surname;
	String civil_statut;
	String mail_adresse;
	int number;
	
	/**
	 * @param name
	 * @param surname
	 * @param civil_statut
	 * @param mail_adresse
	 * @param number
	 */
	public Passenger(String name, String surname, String civil_statut, String mail_adresse, int number) {
		this.name = name;
		this.surname = surname;
		this.civil_statut = civil_statut;
		this.mail_adresse = mail_adresse;
		this.number = number;
	}
	
}

public interface PassengerDAO{
	
	/**
	 * @param flight
	 * @ search a flight
	 */
	
	void searchFlight(Flight flight);
	
	/**
	 *@param flight
	 *@Access to information of a flight
	 */
	
	void putFlight ( Flight flight);
	
	/**
	 * @param reservation
	 * @ booking a flight
	 */
	
	void putReservation(Reservation reservation);
	
	/**
	 * @param reservation
	 * @ cancel a reservation
	 */
	void cancelReservation( Reservation reservation);
	
	
}
