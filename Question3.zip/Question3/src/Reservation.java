/**
 * 
 */

/**
 * @author DANSO
 *
 */
public class Reservation {
	int resevation_id ;
	String date;
	
	/**
	 * @param resevation_id
	 * @param price
	 * @param date
	 */
	public Reservation(int resevation_id,String date) {
		this.resevation_id = resevation_id;
		this.date = date;
	}
	
	
public interface ReservationDAO{
	/**
	 *@param resrervation
	 * @return information of a booking
	 */
	
	Reservation getReservationInformation(Reservation reservation);
	
	
	}
	
	
	

	
					
	
	
	

}
