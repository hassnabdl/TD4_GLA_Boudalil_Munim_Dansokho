
/**
 * @author DANSO
 *
 */
public class Pilot {
	String name;
	String surname;
	String qualifications;
	String experience;
	
	/**
	 * @param name
	 * @param surname
	 * @param qualifications
	 * @param experience
	 */
	public Pilot(String name, String surname, String qualifications, String experience) {
		this.name = name;
		this.surname = surname;
		this.qualifications = qualifications;
		this.experience = experience;
	}
	
	
}
	
public interface PilotDAO{
	
	/**
	 * @param flight
	 @ add a  flight
	 */
	void putFlight(Flight flight);
	
	/**
	 * @ modify or update a information of flight 
	 * 
	 */
	void postFlightInformation(Flight flight);
	
	/**
	 * @param flight
	 * @delete a flight
	 */
	void deleteFlight(Flight flight);
	
	
	/**
	 * @param reservation
	 * @  accept or cancel a reservation
	 */
	
	boolean isAcceptedReservation(Reservation reservation);
	
	
	}
	


