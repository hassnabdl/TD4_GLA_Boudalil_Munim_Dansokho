import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * @author DANSO
 *
 */
public class Flight {
	
	LocalDateTime duration;
	int available_number_seats;
	double price;
	String meeting_place;
	String departure;
	String destination;
	String time ;
	int id;
	Pilot pilot;
	List<Passenger> passengers = new ArrayList<Passenger>() ;

/**
 * @param duration
 * @param available_number_seats
 * @param price
 * @param meeting_place
 * @param departure
 * @param destination
 * @param time
 * @param id
 * @param pilot
 * @param passengers
 */
public Flight(LocalDateTime duration, int available_number_seats, double price, String meeting_place, String departure,
		String destination, String time, int id, Pilot pilot, List<Passenger> passengers) {
	this.duration = duration;
	this.available_number_seats = available_number_seats;
	this.price = price;
	this.meeting_place = meeting_place;
	this.departure = departure;
	this.destination = destination;
	this.time = time;
	this.id = id;
	this.pilot = pilot;
	this.passengers = passengers;
	
	
	
}


public interface FlightDAO{

/**
 * @return the list of booked flights
 */

List<Flight>  getBookedFlights();

/**
 *@param user
 * @return the list of booked flights for a specific user
 */

List<Flight>  getFlights(String user);


/**
 * @return the list of booked flights
 */

	List<Flight>  getFlights();


/**
 *@param flight
 * @return information about a flight
 */

Flight  getFlightInformation(Flight flight);


}

	


